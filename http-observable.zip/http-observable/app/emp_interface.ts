export interface Iemployee{
    id:number;
    name:string;
    age:number;
}