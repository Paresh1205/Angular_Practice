import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TempRefrenceComponent } from './temp-refrence.component';

describe('TempRefrenceComponent', () => {
  let component: TempRefrenceComponent;
  let fixture: ComponentFixture<TempRefrenceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TempRefrenceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TempRefrenceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
