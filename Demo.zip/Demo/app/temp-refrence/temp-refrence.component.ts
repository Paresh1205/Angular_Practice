import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-temp-refrence',
  templateUrl: './temp-refrence.component.html',
  styleUrls: ['./temp-refrence.component.css']
})
export class TempRefrenceComponent implements OnInit {

  public name="PAresh KOrani";

  logmessage(value){
    console.log(value);
  }
  constructor() { }

  ngOnInit() {
  }

}
