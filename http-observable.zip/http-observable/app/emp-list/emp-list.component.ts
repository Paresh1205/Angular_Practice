import { Component, OnInit } from '@angular/core';
import { EmployeeServiceService } from '../employee-service.service';

@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit {
  public employees = []
  constructor(private _empService : EmployeeServiceService) { }

  
  ngOnInit() {
    this._empService.getData().subscribe(data=>this.employees=data);
  }

}
